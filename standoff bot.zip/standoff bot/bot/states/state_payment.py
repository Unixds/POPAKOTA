# - *- coding: utf- 8 - *-
from aiogram.dispatcher.filters.state import State, StatesGroup


class StorageQiwi(StatesGroup):
    here_input_sber_amount = State()
    here_input_img_amount = State()
    here_input_sber_rek = State()
    here_input_sber_min = State()

# Создаем класс для состояний пользователя
class QiwiStates(StatesGroup):
    qiwi_number = State()
    
